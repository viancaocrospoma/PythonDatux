nume=float(input("Ingrese num: "))
if nume%2==0:
    print("EL NUMERO ES MULTIPLE DE 2")
else:
    print("EL NUMERO NO ES MULTIPLE DE 2")