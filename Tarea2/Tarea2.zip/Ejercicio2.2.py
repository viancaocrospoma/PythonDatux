h = int(input('Ingrese los lados del cuadrado: '))
for _ in range(h):
    print('*****')
 