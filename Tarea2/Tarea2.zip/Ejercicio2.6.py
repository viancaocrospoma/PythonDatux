def saludar(nombe):
    print("NOMBRE:",nombe)
nombe="Vianca"
saludar(nombe)


def realizarTarea(tarea):
    print("Tarea:",tarea)
tarea="Completada"
realizarTarea(tarea)


def despedirse(nombre): 
    print("Mi nombre completo es: ",nombre)
nombre="Vianca ocrospoma"
despedirse(nombre)
    
