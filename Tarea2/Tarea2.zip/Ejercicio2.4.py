a=[*range(1,101,2)]
print("**********LOS NUMEROS SON**********")
print(a)