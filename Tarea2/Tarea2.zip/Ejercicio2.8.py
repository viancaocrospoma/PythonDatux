import sys

args = sys.argv

print("cantidad de argumentos:", len(args))