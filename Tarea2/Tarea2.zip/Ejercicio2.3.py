h = int(input('Ingrese el lado del triangulo: '))
for f in range(h):
    print('#'* (f+1))