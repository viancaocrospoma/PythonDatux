#9.Escribir un programa que pida al usuario un número entero y muestre por pantalla si es par o
#impar
nume=int(input("Ingrese num:"))
if nume%2==0:
    print("EL NUMERO ES PAR")
else:
    print("EL NUMERO ES IMPAR")