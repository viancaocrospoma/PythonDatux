#.Defina un diccionario con una tupla y una lista de elementos, modifique el ultimo elemento.
