#3.Ingrese 3 valores y realice las operaciones de suma ,resta y multiplicación
num1=int(input("ingrese primer número:"))
num2=int(input("ingrese segundo número:"))
num3=int(input("ingrese tercer número:"))
print(num1+num2+num3)
print(num1-num2-num3)
print(num1*num2*num3)