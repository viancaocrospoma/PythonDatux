#15.iterar una lista de elementos que contengan nombre y edad e imprimir solo los mayores de
#edad.
#Nota : cada elemento de la lista puede ser otra lista [[nombre,edad],.... ]
lis= ['nombre','edad']
sc=[]
sc=input("Ingrese nombre:"+ lis)
sc=input("Ingrese ed:"+ lis)
if 'edad'< 18:
    print("Es menor")
else:
    print("Es mayor")
