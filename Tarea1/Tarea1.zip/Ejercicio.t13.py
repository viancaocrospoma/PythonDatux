#12.Defina una lista de 5 estudiantes realice lo siguiente :
#-el tamaño de la lista.
#-el ultimo elemento.
#-Revierta los elementos.
