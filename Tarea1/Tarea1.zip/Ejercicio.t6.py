#Realice un programa que calcule la suma de los números hasta el valor ingresado.
#Ejemplo : si se ingresa 5 se tendrá que calcular 1+2+3+4+5.
n=int(input("cu5antos numeros sumaras:"))
sum = n*(n+1)/2
print(sum)
print()



  