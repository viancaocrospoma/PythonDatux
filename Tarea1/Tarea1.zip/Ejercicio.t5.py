#5. Realice un programa que imprima la ubicación de su carpeta donde se encuentra trabajando
import sys
print("El nombre es:", sys.argv[0])