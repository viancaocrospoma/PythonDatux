#4.Ingrese un valor e imprima el tipo de dato.
import random
type(random)