#1.Realizar un programa que ingrese sus datos personales e imprimirlos.
nombre=input("ingrese nombre:")
apellido=input("ingrese apellido:")
edad=int(input("ingrese edad:"))
print("Mi nombre es " + str(nombre) + ", mi apellido es " + str(apellido) + " y mi edad es "+ str(edad))
